﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hit : MonoBehaviour {
	 public GameManager gameManager;  
	int damageValue = 1;
	　　  void OnTriggerEnter(Collider col){  
		　　      if (col.gameObject.tag == "Player") 
		              {  
			　　
			GameManager gameManager = col.gameObject.GetComponent<GameManager> ();
			gameManager.SendMessage("PlayerDamaged",damageValue,SendMessageOptions.DontRequireReceiver); 

			　　      }  
		
	}
}
